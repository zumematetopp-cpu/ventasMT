export default async (request) => {
  if (request.method !== 'POST') return new Response('Method Not Allowed', { status: 405 });
  const endpoint = Netlify.env.get('GOOGLE_SHEETS_WEBAPP_URL');
  const token = Netlify.env.get('GOOGLE_SHEETS_API_TOKEN');
  if (!endpoint || !token) return Response.json({ ok:false, error:'Google Sheets todavía no está conectado' }, { status:503 });
  const payment = await request.json();
  const upstream = await fetch(endpoint, {
    method:'POST', headers:{'content-type':'application/json'},
    body:JSON.stringify({ token, action:'recordPayment', payment })
  });
  return new Response(await upstream.text(), { status:upstream.ok?200:502, headers:{'content-type':'application/json'} });
};
