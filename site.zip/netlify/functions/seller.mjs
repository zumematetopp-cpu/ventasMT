export default async (request) => {
  if (request.method !== 'POST') {
    return new Response(JSON.stringify({ ok: false, error: 'Método no permitido' }), {
      status: 405,
      headers: { 'content-type': 'application/json' }
    });
  }

  const endpoint = Netlify.env.get('GOOGLE_SHEETS_WEBAPP_URL');
  const token = Netlify.env.get('GOOGLE_SHEETS_API_TOKEN');
  if (!endpoint || !token) {
    return new Response(JSON.stringify({ ok: false, error: 'Google Sheets todavía no está conectado' }), {
      status: 503,
      headers: { 'content-type': 'application/json' }
    });
  }

  try {
    const seller = await request.json();
    const upstream = await fetch(endpoint, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ token, action: 'registerSeller', seller })
    });
    const text = await upstream.text();
    return new Response(text, {
      status: upstream.ok ? 200 : 502,
      headers: { 'content-type': 'application/json' }
    });
  } catch (error) {
    return new Response(JSON.stringify({ ok: false, error: String(error?.message || error) }), {
      status: 500,
      headers: { 'content-type': 'application/json' }
    });
  }
};
